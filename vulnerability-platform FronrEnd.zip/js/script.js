// Simple client-side validation
const forms = document.querySelectorAll('form');
forms.forEach(form => {
  form.addEventListener('submit', e => {
    e.preventDefault();
    alert('Form submitted (frontend only). You can connect a backend later!');
  });
});
